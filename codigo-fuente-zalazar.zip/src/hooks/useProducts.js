import { useEffect, useState } from 'react'
import { fallbackProducts } from '../data/products'
import { fetchSanityProducts, sanityEnabled, urlFor } from '../lib/sanity'

function mapSanityProduct(product) {
  return {
    id: product._id,
    title: product.title,
    price: product.price,
    category: product.category,
    description: product.description,
    image: product.image ? urlFor(product.image).width(900).height(700).fit('crop').url() : '',
  }
}

export function useProducts() {
  const [products, setProducts] = useState(fallbackProducts)
  const [loading, setLoading] = useState(sanityEnabled)
  const [error, setError] = useState('')

  useEffect(() => {
    let cancelled = false

    async function loadProducts() {
      if (!sanityEnabled) {
        setLoading(false)
        return
      }

      try {
        const sanityProducts = await fetchSanityProducts()
        if (cancelled) return

        if (sanityProducts.length > 0) {
          setProducts(sanityProducts.map(mapSanityProduct))
        }
      } catch (loadError) {
        if (!cancelled) {
          setError('No se pudo cargar Sanity. Se muestran productos de ejemplo.')
        }
      } finally {
        if (!cancelled) {
          setLoading(false)
        }
      }
    }

    loadProducts()

    return () => {
      cancelled = true
    }
  }, [])

  return {
    products,
    loading,
    error,
    sanityEnabled,
  }
}
