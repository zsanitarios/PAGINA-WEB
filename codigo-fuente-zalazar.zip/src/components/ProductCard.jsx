import { MessageCircleMore, Tag } from 'lucide-react'

function formatPrice(price) {
  return new Intl.NumberFormat('es-AR', {
    style: 'currency',
    currency: 'ARS',
    maximumFractionDigits: 0,
  }).format(price)
}

function ProductCard({ product }) {
  const hasPrice = typeof product.price === 'number' && Number.isFinite(product.price) && product.price > 0
  const message = encodeURIComponent(
    `Hola Gas y Sanitarios Zalazar, quiero consultar por ${product.title}.`,
  )

  return (
    <article className="group overflow-hidden rounded-[2rem] border border-white/10 bg-zinc-950 shadow-panel transition duration-300 hover:-translate-y-1 hover:border-brand/50 hover:shadow-soft">
      <div className="aspect-[4/3] overflow-hidden bg-zinc-900">
        <img
          src={product.image}
          alt={product.title}
          className="h-full w-full object-cover transition duration-500 group-hover:scale-105"
        />
      </div>

      <div className="p-6">
        <div className="flex items-center justify-between gap-3">
          {product.category ? (
            <span className="inline-flex items-center gap-2 rounded-full bg-brand/15 px-3 py-1 text-xs font-semibold uppercase tracking-[0.2em] text-brand-light">
              <Tag className="h-3.5 w-3.5" />
              {product.category}
            </span>
          ) : (
            <span className="inline-flex items-center gap-2 rounded-full bg-white/5 px-3 py-1 text-xs font-semibold uppercase tracking-[0.2em] text-zinc-400">
              <Tag className="h-3.5 w-3.5" />
              Producto
            </span>
          )}
          <p className="text-right text-lg font-extrabold text-brand">
            {hasPrice ? formatPrice(product.price) : 'Consultar precio'}
          </p>
        </div>

        <h3 className="mt-4 text-xl font-bold text-white">{product.title}</h3>
        <p className="mt-3 text-sm leading-6 text-zinc-400">{product.description}</p>

        <a
          href={`https://wa.me/5491140935336?text=${message}`}
          target="_blank"
          rel="noreferrer"
          className="mt-6 inline-flex w-full items-center justify-center gap-2 rounded-full bg-brand px-5 py-3 text-sm font-semibold text-white transition hover:bg-brand-dark"
        >
          <MessageCircleMore className="h-4 w-4" />
          Consultar por WhatsApp
        </a>
      </div>
    </article>
  )
}

export default ProductCard
