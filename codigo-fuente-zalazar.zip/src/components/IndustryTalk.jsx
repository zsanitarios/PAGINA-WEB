import { Play, Youtube } from 'lucide-react'
import comercioSanitarioPhoto from '../assets/comercio-sanitario-zalazar.jpg'

const videoUrl = 'https://www.youtube.com/watch?v=Lg_jb9Fdf-0'

function IndustryTalk() {
  return (
    <section className="bg-ink px-6 py-16 sm:py-20">
      <div className="mx-auto max-w-6xl overflow-hidden rounded-[2rem] border border-white/10 bg-panel shadow-panel">
        <div className="grid lg:grid-cols-[1.05fr_0.95fr]">
          <a
            href={videoUrl}
            target="_blank"
            rel="noreferrer"
            aria-label="Ver la charla de Sanitarios Zalazar en YouTube"
            className="group relative block min-h-72 overflow-hidden bg-brand-dark lg:min-h-full"
          >
            <img
              src={comercioSanitarioPhoto}
              alt="Equipo de Sanitarios Zalazar participando en Comercio Sanitario"
              className="h-full w-full object-cover transition duration-500 group-hover:scale-105"
            />
            <span className="absolute inset-0 bg-gradient-to-t from-black/65 via-transparent to-transparent" />
            <span className="absolute bottom-6 left-6 inline-flex items-center gap-2 rounded-full bg-red-600 px-4 py-2 text-sm font-bold text-white shadow-lg">
              <Play className="h-4 w-4 fill-current" aria-hidden="true" />
              Ver en YouTube
            </span>
          </a>

          <div className="flex flex-col justify-center p-7 sm:p-10 lg:p-12">
            <p className="text-sm font-semibold uppercase tracking-[0.24em] text-brand-light">
              Comercio Sanitario · Episodio N°9
            </p>
            <h2 className="mt-4 text-3xl font-extrabold tracking-tight text-white sm:text-4xl">
              Sanitarios Zalazar, presentes en la charla
            </h2>
            <p className="mt-5 text-base leading-relaxed text-zinc-300 sm:text-lg">
              Participamos de una conversación junto a referentes del sector para compartir experiencia, actualidad y el trabajo que hacemos todos los días.
            </p>
            <a
              href={videoUrl}
              target="_blank"
              rel="noreferrer"
              className="mt-8 inline-flex w-fit items-center gap-3 rounded-full bg-white px-6 py-3.5 text-sm font-bold text-black transition hover:bg-zinc-200 focus:outline-none focus:ring-2 focus:ring-brand-light focus:ring-offset-2 focus:ring-offset-ink"
            >
              <Youtube className="h-5 w-5 text-red-600" aria-hidden="true" />
              Mirar la charla completa
            </a>
          </div>
        </div>
      </div>
    </section>
  )
}

export default IndustryTalk
