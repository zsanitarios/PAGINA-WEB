import { useState } from 'react'
import { Search, ShoppingBag } from 'lucide-react'
import ProductCard from './ProductCard'

function Store({ products }) {
  const categories = ['Todos', ...new Set(products.map((product) => product.category).filter(Boolean))]
  const [activeCategory, setActiveCategory] = useState('Todos')
  const [searchTerm, setSearchTerm] = useState('')

  const productsByCategory =
    activeCategory === 'Todos'
      ? products
      : products.filter((product) => product.category === activeCategory)

  const normalizedSearch = searchTerm.trim().toLowerCase()
  const visibleProducts = normalizedSearch
    ? productsByCategory.filter((product) => {
        const searchableText = [product.title, product.category, product.description]
          .filter(Boolean)
          .join(' ')
          .toLowerCase()

        return searchableText.includes(normalizedSearch)
      })
    : productsByCategory

  return (
    <section id="tienda" className="border-y border-white/5 bg-ink py-20 sm:py-24">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col gap-6 sm:flex-row sm:items-end sm:justify-between">
          <div className="max-w-2xl">
            <span className="inline-flex items-center gap-2 rounded-full border border-brand/25 bg-brand/10 px-4 py-2 text-sm font-semibold uppercase tracking-[0.2em] text-brand-light">
              <ShoppingBag className="h-4 w-4" />
              Catalogo
            </span>
            <h2 className="mt-5 text-3xl font-bold text-white sm:text-4xl">
              Productos destacados para tu obra
            </h2>
            <p className="mt-4 text-lg text-zinc-400">
              Una seleccion clara de productos para consultar disponibilidad, precio y alternativas por WhatsApp.
            </p>
          </div>
        </div>

        <div className="mt-10 flex gap-3 overflow-x-auto pb-2">
          {categories.map((category) => {
            const count =
              category === 'Todos'
                ? products.length
                : products.filter((product) => product.category === category).length

            const isActive = category === activeCategory

            return (
              <button
                key={category}
                type="button"
                onClick={() => setActiveCategory(category)}
                className={`inline-flex shrink-0 items-center gap-3 rounded-full border px-5 py-3 text-sm font-semibold transition ${
                  isActive
                    ? 'border-brand bg-brand text-white'
                    : 'border-white/10 bg-white/5 text-zinc-300 hover:border-brand/40 hover:text-white'
                }`}
              >
                <span>{category}</span>
                <span
                  className={`rounded-full px-2 py-0.5 text-xs ${
                    isActive ? 'bg-white/20 text-white' : 'bg-white/10 text-zinc-400'
                  }`}
                >
                  {count}
                </span>
              </button>
            )
          })}
        </div>

        <div className="mt-8 max-w-2xl">
          <label htmlFor="product-search" className="sr-only">
            Buscar producto
          </label>
          <div className="relative">
            <Search className="pointer-events-none absolute left-5 top-1/2 h-5 w-5 -translate-y-1/2 text-brand-light" />
            <input
              id="product-search"
              type="search"
              value={searchTerm}
              onChange={(event) => setSearchTerm(event.target.value)}
              placeholder="Buscar producto por nombre, categoria o descripcion..."
              className="w-full rounded-full border border-white/10 bg-white/5 py-4 pl-14 pr-5 text-base text-white outline-none transition placeholder:text-zinc-500 focus:border-brand/70 focus:bg-white/10"
            />
          </div>
        </div>

        {visibleProducts.length > 0 ? (
          <div className="mt-12 grid gap-6 sm:grid-cols-2 xl:grid-cols-4">
            {visibleProducts.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        ) : (
          <div className="mt-12 rounded-[2rem] border border-white/10 bg-white/5 p-8 text-center text-zinc-300">
            No encontramos productos con esa busqueda.
          </div>
        )}
      </div>
    </section>
  )
}

export default Store
