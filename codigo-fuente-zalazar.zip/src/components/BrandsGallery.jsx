import { BadgeCheck, Building2 } from 'lucide-react'
import awaductLogo from '../assets/brands/awaduct.svg'
import capeaLogo from '../assets/brands/capea.svg'
import ferrumLogo from '../assets/brands/ferrum.svg'
import fvLogo from '../assets/brands/fv.svg'
import peiranoLogo from '../assets/brands/peirano.svg'
import rowaLogo from '../assets/brands/rowa.svg'
import saladilloLogo from '../assets/brands/saladillo.svg'
import sigasLogo from '../assets/brands/sigas.svg'
import waterplastLogo from '../assets/brands/waterplast.svg'

const highlights = [
  'Waterplast',
  'FV',
  'Rowa',
  'Awaduct',
  'Sigas',
  'Industria Saladillo',
  'Ferrum',
  'Peirano',
  'Capea',
]

const brandSlides = [
  {
    name: 'Waterplast',
    image: waterplastLogo,
  },
  {
    name: 'FV',
    image: fvLogo,
  },
  {
    name: 'Rowa',
    image: rowaLogo,
  },
  {
    name: 'Awaduct',
    image: awaductLogo,
  },
  {
    name: 'Sigas',
    image: sigasLogo,
  },
  {
    name: 'Industria Saladillo',
    image: saladilloLogo,
  },
  {
    name: 'Ferrum',
    image: ferrumLogo,
  },
  {
    name: 'Peirano',
    image: peiranoLogo,
  },
  {
    name: 'Capea',
    image: capeaLogo,
  },
]

function BrandCard({ brand }) {
  return (
    <article className="w-[230px] shrink-0 overflow-hidden rounded-[1.75rem] border border-white/10 bg-white shadow-panel sm:w-[280px]">
      <img
        src={brand.image}
        alt={`Logo de ${brand.name}`}
        className="h-[130px] w-full object-cover sm:h-[155px]"
      />
    </article>
  )
}

function CarouselTrack() {
  const slides = [...brandSlides, ...brandSlides]

  return (
    <div className="flex w-max animate-marquee gap-5 pr-5 will-change-transform">
      {slides.map((brand, index) => (
        <BrandCard key={`${brand.name}-${index}`} brand={brand} />
      ))}
    </div>
  )
}

function BrandsGallery() {
  return (
    <section id="marcas" className="overflow-hidden bg-black py-20 sm:py-24">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="grid gap-10 lg:grid-cols-[0.8fr_1.2fr] lg:items-end">
          <div className="max-w-xl">
            <span className="inline-flex items-center gap-2 rounded-full border border-brand/25 bg-brand/10 px-4 py-2 text-sm font-semibold uppercase tracking-[0.2em] text-brand-light">
              <Building2 className="h-4 w-4" />
              Marcas
            </span>
            <h2 className="mt-5 text-3xl font-bold text-white sm:text-4xl">
              Galeria de marcas con las que trabajamos
            </h2>
            <p className="mt-4 text-lg text-zinc-400">
              Trabajamos con marcas reconocidas en sanitarios, griferia, termofusion,
              tanques y bombas para cubrir distintas necesidades de obra.
            </p>
          </div>

          <div className="flex flex-wrap gap-3">
            {highlights.map((brand) => (
              <span
                key={brand}
                className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/5 px-4 py-2 text-sm font-medium text-zinc-200"
              >
                <BadgeCheck className="h-4 w-4 text-brand-light" />
                {brand}
              </span>
            ))}
          </div>
        </div>
      </div>

      <div className="relative mt-12">
        <div className="pointer-events-none absolute inset-y-0 left-0 z-10 w-24 bg-gradient-to-r from-black to-transparent" />
        <div className="pointer-events-none absolute inset-y-0 right-0 z-10 w-24 bg-gradient-to-l from-black to-transparent" />
        <CarouselTrack />
      </div>
    </section>
  )
}

export default BrandsGallery
