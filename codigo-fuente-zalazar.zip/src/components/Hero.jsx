import { ArrowDown, BadgeCheck, Building2, Instagram, Truck } from 'lucide-react'
import fvLogo from '../assets/brands/fv.svg'

function Hero() {
  return (
    <section
      id="inicio"
      className="relative overflow-hidden bg-hero py-20 text-white sm:py-24 lg:py-28"
    >
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,_rgba(47,110,214,0.42),_transparent_26%),radial-gradient(circle_at_bottom_left,_rgba(255,255,255,0.08),_transparent_24%)]" />
      <div className="absolute inset-x-0 bottom-0 h-40 bg-gradient-to-t from-ink to-transparent" />

      <div className="relative mx-auto grid max-w-7xl items-center gap-12 px-4 sm:px-6 lg:grid-cols-[1.1fr_0.9fr] lg:px-8">
        <div>
          <span className="inline-flex items-center gap-2 rounded-full border border-white/20 bg-white/10 px-4 py-2 text-sm font-semibold backdrop-blur">
            <BadgeCheck className="h-4 w-4" />
            Asesoramiento para obra y remodelacion
          </span>

          <h1 className="mt-8 max-w-3xl text-4xl font-extrabold leading-tight sm:text-5xl lg:text-6xl">
            Gas y Sanitarios Zalazar
          </h1>
          <p className="mt-6 max-w-2xl text-lg leading-8 text-zinc-200 sm:text-xl">
            <span className="block">💧| Aguas, Tanques y Grifería.</span>
            <span className="block">👷| Gas, Loza Sanitaria y lo principal para tu Obra.</span>
            <span className="block">🕒| 20 Años en el Rubro</span>
          </p>

          <div className="mt-10 flex flex-col gap-4 sm:flex-row">
            <a
              href="/tienda"
              className="inline-flex items-center justify-center gap-2 rounded-full bg-white px-7 py-4 text-base font-semibold text-black transition hover:bg-zinc-100"
            >
              Ver tienda
              <ArrowDown className="h-5 w-5" />
            </a>
            <a
              href="#ubicacion"
              className="inline-flex items-center justify-center rounded-full border border-white/30 px-7 py-4 text-base font-semibold text-white transition hover:bg-white/10"
            >
              Como llegar
            </a>
            <a
              href="https://www.instagram.com/sanitarios.zalazar/"
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center justify-center gap-2 rounded-full border border-brand-light/50 bg-brand/20 px-7 py-4 text-base font-semibold text-white transition hover:bg-brand/35"
            >
              <Instagram className="h-5 w-5" />
              Instagram
            </a>
          </div>
        </div>

        <div className="rounded-[2rem] border border-white/10 bg-panel p-6 shadow-panel backdrop-blur">
          <div className="grid gap-4">
            <div className="rounded-3xl border border-brand-light/40 bg-white p-5 text-slate-950">
              <div className="flex items-center gap-4">
                <img
                  src={fvLogo}
                  alt="Logo de FV"
                  className="h-14 w-20 rounded-2xl object-contain"
                />
                <div>
                  <p className="text-xs font-semibold uppercase tracking-[0.25em] text-brand">
                    FV
                  </p>
                  <p className="mt-1 text-lg font-black">
                    Representantes Oficiales de FV en Zona Norte
                  </p>
                </div>
              </div>
            </div>

            <div className="rounded-3xl border border-white/10 bg-white p-5 text-slate-900">
              <div className="flex items-center gap-4">
                <div className="rounded-2xl bg-brand-light p-3 text-brand">
                  <Building2 className="h-6 w-6" />
                </div>
                <div>
                  <p className="text-sm font-semibold uppercase tracking-[0.25em] text-brand">
                    Sucursal
                  </p>
                  <p className="mt-1 text-lg font-bold">Av. Tomas Marquez 1248, Pilar</p>
                </div>
              </div>
            </div>

            <div className="rounded-3xl border border-white/10 bg-black/30 p-6">
              <div className="flex items-start gap-4">
                <div className="rounded-2xl bg-white/15 p-3">
                  <Truck className="h-6 w-6" />
                </div>
                <div>
                  <p className="text-sm font-semibold uppercase tracking-[0.25em] text-white/80">
                    Materiales seleccionados
                  </p>
                  <p className="mt-2 text-lg font-semibold">
                    Griferia, termotanques, caños, sanitarios y mas para resolver tu compra en un solo lugar.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

export default Hero
