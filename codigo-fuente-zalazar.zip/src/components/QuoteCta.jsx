import { MessageCircleMore } from 'lucide-react'

const whatsappLink =
  'https://wa.me/5491140935336?text=Hola%20Gas%20y%20Sanitarios%20Zalazar%2C%20quiero%20pedir%20un%20presupuesto.'

function QuoteCta() {
  return (
    <section className="border-y border-white/10 bg-brand-dark px-6 py-12 sm:py-16">
      <div className="mx-auto flex max-w-6xl flex-col items-start justify-between gap-7 rounded-3xl border border-white/15 bg-white/10 p-7 shadow-panel backdrop-blur-sm sm:flex-row sm:items-center sm:p-10">
        <div>
          <p className="text-sm font-semibold uppercase tracking-[0.24em] text-brand-light">
            Para tu obra o remodelación
          </p>
          <h2 className="mt-3 text-3xl font-extrabold tracking-tight text-white sm:text-4xl">
            PRESUPUESTÁ YA
          </h2>
          <p className="mt-3 max-w-xl text-base leading-relaxed text-white/75">
            Contanos qué necesitás y te ayudamos a armar el presupuesto ideal.
          </p>
        </div>

        <a
          href={whatsappLink}
          target="_blank"
          rel="noreferrer"
          className="inline-flex shrink-0 items-center gap-3 rounded-full bg-green-500 px-6 py-3.5 text-sm font-bold text-white shadow-lg transition hover:scale-[1.02] hover:bg-green-600 focus:outline-none focus:ring-2 focus:ring-white focus:ring-offset-2 focus:ring-offset-brand-dark"
        >
          <MessageCircleMore className="h-5 w-5" aria-hidden="true" />
          Pedí tu presupuesto
        </a>
      </div>
    </section>
  )
}

export default QuoteCta
