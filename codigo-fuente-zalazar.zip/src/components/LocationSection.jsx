import { MapPinned } from 'lucide-react'

const mapsLink =
  'https://www.google.com/maps?sca_esv=2cda95c598b12d52&output=search&q=sanitarios+zalazar&source=lnms&fbs=ADc_l-bpk8W4E-qsVlOvbGJcDwpn4CbM0gHaMP9RLFWGd8kHNhTJmj_r203Jn6uBSzsvMQA06cx6S_-rciuKUa3AoaNQ_ldwmJy4IAzDctR5xPsLWyUNTq_UcLXfQw50cBroztmRfskeWnY5V8Wmj_Ji7zfSNNt-NCdO-ekZlrNuvjUo8NY7rSIzI-8eZZCZ3Bz9rM_M41ZVC8hlrnmY8wprb2ASJs4-UA&entry=mc&ved=1t:200715&ictx=111'

function LocationSection() {
  return (
    <section id="ubicacion" className="bg-black py-20">
      <div className="mx-auto grid max-w-7xl gap-8 px-4 sm:px-6 lg:grid-cols-[0.9fr_1.1fr] lg:px-8">
        <div className="rounded-3xl border border-white/10 bg-panel p-8 text-white shadow-panel backdrop-blur">
          <span className="inline-flex items-center gap-2 rounded-full border border-brand/20 bg-brand/10 px-4 py-2 text-sm font-semibold uppercase tracking-[0.2em] text-brand-light">
            <MapPinned className="h-4 w-4" />
            Ubicacion
          </span>
          <h2 className="mt-6 text-3xl font-bold sm:text-4xl">Visitanos en Pilar</h2>
          <p className="mt-4 text-lg text-zinc-300">
            Estamos para asesorarte en cada etapa de tu obra, remodelacion o mantenimiento.
          </p>
          <p className="mt-8 text-xl font-semibold text-white">Av. Tomas Marquez 1248, Pilar</p>
          <a
            href={mapsLink}
            target="_blank"
            rel="noreferrer"
            className="mt-8 inline-flex rounded-full bg-brand px-6 py-3 font-semibold text-white transition hover:bg-brand-dark"
          >
            Abrir en Google Maps
          </a>
        </div>

        <div className="overflow-hidden rounded-3xl border border-white/10 bg-zinc-950 shadow-panel">
          <a
            href={mapsLink}
            target="_blank"
            rel="noreferrer"
            className="flex h-full min-h-[320px] flex-col justify-between bg-[radial-gradient(circle_at_top,_rgba(0,71,171,0.28),_transparent_38%),linear-gradient(180deg,_#141414,_#090909)] p-8 transition hover:bg-[radial-gradient(circle_at_top,_rgba(0,71,171,0.36),_transparent_42%),linear-gradient(180deg,_#151515,_#050505)]"
          >
            <div>
              <p className="text-sm font-semibold uppercase tracking-[0.3em] text-brand-light">
                Punto de venta
              </p>
              <h3 className="mt-3 text-3xl font-bold text-white">Ubicacion y acceso rapido</h3>
              <p className="mt-4 max-w-md text-zinc-400">
                Consulta la ubicacion exacta del local y abre el recorrido directo desde Google Maps.
              </p>
            </div>
            <div className="mt-10 rounded-3xl border border-white/10 bg-white/5 p-6">
              <p className="text-sm uppercase tracking-[0.25em] text-zinc-500">Direccion</p>
              <p className="mt-3 text-2xl font-semibold text-white">Av. Tomas Marquez 1248</p>
              <p className="mt-2 text-zinc-400">Pilar, Buenos Aires</p>
            </div>
          </a>
        </div>
      </div>
    </section>
  )
}

export default LocationSection
