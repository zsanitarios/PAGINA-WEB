import { MessageCircleMore } from 'lucide-react'

const whatsappLink =
  'https://wa.me/5491140935336?text=Hola%20Gas%20y%20Sanitarios%20Zalazar%2C%20quiero%20hacer%20una%20consulta.'

function WhatsAppButton() {
  return (
    <a
      href={whatsappLink}
      target="_blank"
      rel="noreferrer"
      aria-label="Contactar por WhatsApp"
      className="fixed bottom-5 right-5 z-50 inline-flex h-16 w-16 items-center justify-center rounded-full bg-green-500 text-white shadow-2xl transition hover:scale-105 hover:bg-green-600"
    >
      <MessageCircleMore className="h-8 w-8" />
    </a>
  )
}

export default WhatsAppButton
