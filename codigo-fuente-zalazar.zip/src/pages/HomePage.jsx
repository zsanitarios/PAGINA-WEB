import BrandsGallery from '../components/BrandsGallery'
import Hero from '../components/Hero'
import IndustryTalk from '../components/IndustryTalk'
import LocationSection from '../components/LocationSection'
import QuoteCta from '../components/QuoteCta'

function HomePage() {
  return (
    <main>
      <Hero />
      <QuoteCta />
      <BrandsGallery />
      <IndustryTalk />
      <LocationSection />
    </main>
  )
}

export default HomePage
