import { ArrowLeft, Store as StoreIcon } from 'lucide-react'
import Store from '../components/Store'
import { useProducts } from '../hooks/useProducts'

function StorePage() {
  const { products, loading, error, sanityEnabled } = useProducts()

  return (
    <main className="min-h-screen bg-ink pt-10">
      <section className="border-b border-white/5 bg-[radial-gradient(circle_at_top,_rgba(0,71,171,0.18),_transparent_40%),linear-gradient(180deg,_#060606,_#0b0b0b)] py-16">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <a
            href="/"
            className="inline-flex items-center gap-2 text-sm font-semibold text-zinc-300 transition hover:text-white"
          >
            <ArrowLeft className="h-4 w-4" />
            Volver al inicio
          </a>
          <div className="mt-8 max-w-3xl">
            <span className="inline-flex items-center gap-2 rounded-full border border-brand/25 bg-brand/10 px-4 py-2 text-sm font-semibold uppercase tracking-[0.2em] text-brand-light">
              <StoreIcon className="h-4 w-4" />
              Tienda
            </span>
            <h1 className="mt-5 text-4xl font-bold text-white sm:text-5xl">
              Catalogo completo de productos
            </h1>
            <p className="mt-4 text-lg text-zinc-400">
              Explora por categoria y consulta cada producto de forma directa por WhatsApp.
            </p>
            {!sanityEnabled && (
              <p className="mt-5 max-w-2xl rounded-2xl border border-amber-500/30 bg-amber-500/10 px-4 py-3 text-sm text-amber-100">
                Sanity todavia no esta conectado en esta copia. La tienda muestra productos de ejemplo
                hasta que cargues las variables del proyecto.
              </p>
            )}
            {error && (
              <p className="mt-5 max-w-2xl rounded-2xl border border-amber-500/30 bg-amber-500/10 px-4 py-3 text-sm text-amber-100">
                {error}
              </p>
            )}
          </div>
        </div>
      </section>
      {loading && (
        <div className="mx-auto max-w-7xl px-4 pt-10 text-sm text-zinc-400 sm:px-6 lg:px-8">
          Cargando catalogo...
        </div>
      )}
      <Store products={products} />
    </main>
  )
}

export default StorePage
