export const fallbackProducts = [
  {
    id: 1,
    title: 'Griferia Monocomando Cocina',
    price: 98500,
    category: 'Grifer\u00eda',
    image:
      'https://images.unsplash.com/photo-1585704032915-c3400ca199e7?auto=format&fit=crop&w=900&q=80',
    description: 'Diseno cromado de alta resistencia para cocina moderna.',
  },
  {
    id: 2,
    title: 'Griferia para Bano Pico Alto',
    price: 76400,
    category: 'Grifer\u00eda',
    image:
      'https://images.unsplash.com/photo-1584622650111-993a426fbf0a?auto=format&fit=crop&w=900&q=80',
    description: 'Linea compacta y elegante para lavatorio con terminacion cromada.',
  },
  {
    id: 3,
    title: 'Termotanque Alta Recuperacion',
    price: 412000,
    category: 'Termotanques',
    image:
      'https://images.unsplash.com/photo-1621905252507-b35492cc74b4?auto=format&fit=crop&w=900&q=80',
    description: 'Ideal para uso intensivo en hogar u obra con gran rendimiento.',
  },
  {
    id: 4,
    title: 'Termotanque Compacto Multigas',
    price: 358000,
    category: 'Termotanques',
    image:
      'https://images.unsplash.com/photo-1595515106969-1ce29566ff1c?auto=format&fit=crop&w=900&q=80',
    description: 'Equipo confiable para instalaciones residenciales con excelente recuperacion.',
  },
  {
    id: 5,
    title: 'Kit Caños Agua Fria y Caliente',
    price: 67300,
    category: 'Tuber\u00edas',
    image:
      'https://images.unsplash.com/photo-1607472586893-edb57bdc0e39?auto=format&fit=crop&w=900&q=80',
    description: 'Solucion completa para instalaciones confiables y duraderas.',
  },
  {
    id: 6,
    title: 'Codo y Union para Gas',
    price: 19400,
    category: 'Tuber\u00edas',
    image:
      'https://images.unsplash.com/photo-1574359411659-15573f979f55?auto=format&fit=crop&w=900&q=80',
    description: 'Piezas esenciales para armado de redes con terminacion precisa y segura.',
  },
  {
    id: 7,
    title: 'Vanitory con Bacha Ferrum',
    price: 238900,
    category: 'Sanitarios',
    image:
      'https://images.unsplash.com/photo-1505693416388-ac5ce068fe85?auto=format&fit=crop&w=900&q=80',
    description: 'Linea sanitaria elegante para banos residenciales y comerciales.',
  },
  {
    id: 8,
    title: 'Inodoro Largo con Mochila',
    price: 189500,
    category: 'Sanitarios',
    image:
      'https://images.unsplash.com/photo-1620626011761-996317b8d101?auto=format&fit=crop&w=900&q=80',
    description: 'Modelo de alta resistencia con diseno funcional para uso diario.',
  },
  {
    id: 9,
    title: 'Bomba Presurizadora Domestica',
    price: 146800,
    category: 'Bombas',
    image:
      'https://images.unsplash.com/photo-1620626011761-996317b8d101?auto=format&fit=crop&w=900&q=80',
    description: 'Mejora la presion de agua en instalaciones residenciales de forma estable.',
  },
  {
    id: 10,
    title: 'Bomba Centrifuga para Tanque',
    price: 228400,
    category: 'Bombas',
    image:
      'https://images.unsplash.com/photo-1618220048045-10a6dbdf83e0?auto=format&fit=crop&w=900&q=80',
    description: 'Alternativa robusta para impulsion de agua con buen caudal y rendimiento.',
  },
]
