import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  // GitHub Pages publica este repositorio dentro de /PAGINA-WEB/.
  base: process.env.GITHUB_ACTIONS ? '/PAGINA-WEB/' : '/',
  plugins: [react()],
})
