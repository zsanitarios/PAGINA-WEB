import { Instagram, MessageCircleMore, Menu, X } from 'lucide-react'
import { useState } from 'react'
import logo from '../assets/logo-zalazar.jpg'

function Navbar({ isStorePage = false }) {
  const [open, setOpen] = useState(false)
  const links = isStorePage
    ? [
        { label: 'Inicio', href: '/' },
        { label: 'Tienda', href: '/tienda' },
      ]
    : [
        { label: 'Inicio', href: '#inicio' },
        { label: 'Marcas', href: '#marcas' },
        { label: 'Ubicacion', href: '#ubicacion' },
        { label: 'Tienda', href: '/tienda' },
      ]

  return (
    <header className="sticky top-0 z-50 border-b border-white/10 bg-black/80 backdrop-blur-xl">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-4 sm:px-6 lg:px-8">
        <a href="/" className="flex items-center gap-3">
          <img
            src={logo}
            alt="Logo de Gas y Sanitarios Zalazar"
            className="h-12 w-12 rounded-full border border-white/15 object-cover shadow-soft"
          />
          <div>
            <p className="text-xs font-semibold uppercase tracking-[0.32em] text-brand-light">
              Pilar
            </p>
            <p className="text-base font-bold text-white">Gas y Sanitarios Zalazar</p>
          </div>
        </a>

        <nav className="hidden items-center gap-8 md:flex">
          {links.map((link) => (
            <a
              key={link.label}
              href={link.href}
              className="text-sm font-semibold text-zinc-300 transition hover:text-white"
            >
              {link.label}
            </a>
          ))}
        </nav>

        <div className="hidden items-center gap-3 md:flex">
          <a
            href="https://www.instagram.com/sanitarios.zalazar/"
            target="_blank"
            rel="noreferrer"
            className="inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/5 px-5 py-3 text-sm font-semibold text-white transition hover:border-brand/50 hover:bg-white/10"
          >
            <Instagram className="h-4 w-4" />
            Instagram
          </a>
          <a
            href="https://wa.me/5491140935336?text=Hola%20Gas%20y%20Sanitarios%20Zalazar%2C%20quiero%20hacer%20una%20consulta."
            target="_blank"
            rel="noreferrer"
            className="inline-flex items-center gap-2 rounded-full border border-brand/60 bg-brand px-5 py-3 text-sm font-semibold text-white transition hover:bg-brand-dark"
          >
            <MessageCircleMore className="h-4 w-4" />
            Contacto
          </a>
        </div>

        <button
          type="button"
          aria-label="Abrir menu"
          className="inline-flex rounded-xl border border-white/10 bg-white/5 p-2 text-white md:hidden"
          onClick={() => setOpen((current) => !current)}
        >
          {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </button>
      </div>

      {open && (
        <div className="border-t border-white/10 bg-black md:hidden">
          <nav className="mx-auto flex max-w-7xl flex-col gap-4 px-4 py-5 sm:px-6">
            {links.map((link) => (
              <a
                key={link.label}
                href={link.href}
                className="text-sm font-semibold text-zinc-300"
                onClick={() => setOpen(false)}
              >
                {link.label}
              </a>
            ))}
            <a
              href="https://wa.me/5491140935336?text=Hola%20Gas%20y%20Sanitarios%20Zalazar%2C%20quiero%20hacer%20una%20consulta."
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center justify-center gap-2 rounded-full bg-brand px-5 py-3 text-sm font-semibold text-white"
            >
              <MessageCircleMore className="h-4 w-4" />
              Contacto
            </a>
            <a
              href="https://www.instagram.com/sanitarios.zalazar/"
              target="_blank"
              rel="noreferrer"
              className="inline-flex items-center justify-center gap-2 rounded-full border border-white/15 bg-white/5 px-5 py-3 text-sm font-semibold text-white"
            >
              <Instagram className="h-4 w-4" />
              Instagram
            </a>
          </nav>
        </div>
      )}
    </header>
  )
}

export default Navbar
