export default {
  name: 'product',
  title: 'Producto',
  type: 'document',
  fields: [
    {
      name: 'title',
      title: 'Nombre',
      type: 'string',
      validation: (Rule) => Rule.required().min(3),
    },
    {
      name: 'price',
      title: 'Precio',
      type: 'number',
      validation: (Rule) =>
        Rule.custom((value) => {
          if (value === undefined || value === null) return true
          return value >= 0 || 'El precio no puede ser negativo'
        }),
    },
    {
      name: 'image',
      title: 'Imagen',
      type: 'image',
      options: {
        hotspot: true,
      },
      validation: (Rule) => Rule.required(),
    },
    {
      name: 'category',
      title: 'Categoria',
      type: 'string',
      options: {
        list: [
          { title: 'Grifer\u00eda', value: 'Grifer\u00eda' },
          { title: 'Termotanques', value: 'Termotanques' },
          { title: 'Tuber\u00edas', value: 'Tuber\u00edas' },
          { title: 'Sanitarios', value: 'Sanitarios' },
          { title: 'Bombas', value: 'Bombas' },
        ],
        layout: 'dropdown',
      },
    },
    {
      name: 'description',
      title: 'Descripcion',
      type: 'text',
      rows: 4,
      validation: (Rule) => Rule.required().min(20).max(500),
    },
  ],
  preview: {
    select: {
      title: 'title',
      media: 'image',
      subtitle: 'category',
    },
    prepare({ title, media, subtitle }) {
      return {
        title,
        media,
        subtitle,
      }
    },
  },
}
